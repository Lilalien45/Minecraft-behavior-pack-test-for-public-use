
import { world, system } from "@minecraft/server"

const OWNER = "YOUR_GITHUB_USERNAME"
const REPO = "minecraft-live-cameras"
const BRANCH = "main"

const CAMERA_FILE =
`https://raw.githubusercontent.com/${OWNER}/${REPO}/${BRANCH}/data/cameras.json`

const CHAT_FILE =
`https://raw.githubusercontent.com/${OWNER}/${REPO}/${BRANCH}/data/chat.json`

system.runInterval(() => {

    const players = []

    for (const player of world.getPlayers()) {

        const loc = player.location
        const rot = player.getRotation()

        players.push({
            player: player.name,
            x: loc.x,
            y: loc.y,
            z: loc.z,
            yaw: rot.y,
            pitch: rot.x,
            dimension: player.dimension.id
        })
    }

    const payload = JSON.stringify(players)
    uploadCameraData(payload)

}, 20)

function uploadCameraData(data){

    const body = JSON.stringify({
        message: "camera update",
        content: btoa(data)
    })

    fetch(`https://api.github.com/repos/${OWNER}/${REPO}/contents/data/cameras.json`, {
        method: "PUT",
        headers: {
            "Content-Type":"application/json",
            "Authorization":"Bearer YOUR_GITHUB_TOKEN"
        },
        body
    })
}

world.beforeEvents.chatSend.subscribe(ev => {

    const msg = {
        player: ev.sender.name,
        message: ev.message,
        time: Date.now()
    }

    appendChat(msg)

})

function appendChat(message){

    const body = JSON.stringify({
        message: "chat update",
        content: btoa(JSON.stringify(message))
    })

    fetch(`https://api.github.com/repos/${OWNER}/${REPO}/contents/data/chat.json`,{
        method:"PUT",
        headers:{
            "Content-Type":"application/json",
            "Authorization":"Bearer YOUR_GITHUB_TOKEN"
        },
        body
    })
}

system.runInterval(async () => {

    const res = await fetch(CHAT_FILE)
    const data = await res.json()

    for (const msg of data){
        world.sendMessage("[WEB] "+msg.user+": "+msg.message)
    }

},100)
