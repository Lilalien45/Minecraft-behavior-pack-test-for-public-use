
const OWNER = "YOUR_GITHUB_USERNAME"
const REPO = "minecraft-live-cameras"

const CAMERAS =
`https://raw.githubusercontent.com/${OWNER}/${REPO}/main/data/cameras.json`

const CHAT =
`https://raw.githubusercontent.com/${OWNER}/${REPO}/main/data/chat.json`

async function loadCameras(){

    const res = await fetch(CAMERAS)
    const players = await res.json()

    const cams = document.getElementById("cams")
    cams.innerHTML=""

    for (let p of players){

        let div=document.createElement("div")
        div.className="cam"

        div.innerHTML=
        "<b>"+p.player+"</b><br>"+
        "x:"+p.x+"<br>"+
        "y:"+p.y+"<br>"+
        "z:"+p.z+"<br>"+
        "yaw:"+p.yaw+"<br>"+
        "pitch:"+p.pitch

        cams.appendChild(div)
    }
}

async function loadChat(){

    const res = await fetch(CHAT)
    const chat = await res.json()

    const box=document.getElementById("chat")
    box.innerHTML=""

    for(let m of chat){
        box.innerHTML+= "<div>"+m.player+": "+m.message+"</div>"
    }
}

function send(){
    let msg=document.getElementById("msg").value
    alert("Website chat sending requires GitHub API token integration.")
}

setInterval(loadCameras,2000)
setInterval(loadChat,2000)
