
Minewatch-style Minecraft Camera System

Contents:
- behavior_pack : Bedrock behavior pack with Script API
- website : GitHub Pages site to view cameras and chat
- data : files used by GitHub to store camera/chat data

Setup:
1. Upload the entire project to a GitHub repository.
2. Enable GitHub Pages using the /website folder.
3. Replace YOUR_GITHUB_USERNAME in scripts.
4. Create a GitHub Personal Access Token.
5. Replace YOUR_GITHUB_TOKEN in cameraBridge.js.
6. Import the behavior pack into Minecraft Bedrock.
7. Join the world with the pack enabled.

The website will display player cameras and chat.
